On the Hodge conjecture for Fermat varieties
Deep Bhattacharjee
Research release v1.9.0; 86 pages.
Compile main.tex with pdfLaTeX (three passes); to regenerate the bibliography run BibTeX between passes.
The complete earlier manuscript is retained. Appendix C adds related-work and finite comparison results; it is not a proof of the universal Hodge conjecture or a complete independent audit of Li's conductor argument.
Run python anc/check-li-comparison.py for the seven named-tuple checks.
Permanent work DOI: https://doi.org/10.5281/zenodo.23234362
