# Priority check, 11 October 2026, about 06:45 UTC (final4)

Question, as in the check of 05:05 UTC today (kept beside this one): has anyone else proved the
Hodge conjecture for the Fermat varieties of Theorem A, or for the open degrees 110 and 220 of the
Fermat fourfold?

| Source | Query | Finding |
|---|---|---|
| arXiv (API, newest first) | `all:Fermat AND all:Hodge` | Nothing new since the last check. The newest is still Miranda, Movasati, Rufino and Villaflor, arXiv:2609.27301v2 (23 September 2026), then 2609.12759, Jumagulov's 2608.18134, 2607.13946, 2606.05530 and 2603.00723. |
| Zenodo (API, newest first) | `Fermat AND Hodge` | Our own release v1.7.0 (10.5281/zenodo.23292094) is the newest record; the others are those of the earlier check or unrelated. |

Conclusion: unchanged from the check of 05:05 UTC. Theorem A is the first proof for the degrees
divisible by 44, 51 and 52, and the first proof without Kang's statement for those divisible by 57.
The fourfolds of degree 110 and 220 remain open without Kang's statement, and the Hodge conjecture
itself is not proved.
