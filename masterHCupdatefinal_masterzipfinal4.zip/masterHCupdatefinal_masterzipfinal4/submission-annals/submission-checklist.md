# Submission to the Annals of Mathematics: checklist

Submit through the journal's editorial system at https://ef.msp.org/submit/annals (guidelines: https://annals.math.princeton.edu/submission-guidelines). The manuscript must be a PDF in English. LaTeX is encouraged, and the `aomart` class is optional. There are no publication charges. The Zenodo record serves as the public preprint, so no arXiv endorsement is needed.

## Files

| File | Use |
|---|---|
| `on-the-hodge-conjecture-for-fermat-varieties-final4.pdf` | The manuscript, 83 pages, `amsart`. This is the file to upload. |
| `on-the-hodge-conjecture-for-fermat-varieties-tex-final4.zip` | The LaTeX source with the five figures as PNG. It is not needed at submission; the Annals asks for source only after acceptance. |
| `letter-to-the-editors.txt` | Paste it into the comments field if the form has one. |

## Metadata to enter

- **Title:** On the Hodge conjecture for Fermat varieties
- **Author:** Deep Bhattacharjee (sole author)
- **Affiliation:** Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India
- **Emails:** d.bhattacharjee@erl-forschung.de, itsdeep@live.com
- **ORCID:** 0000-0003-0466-750X
- **MSC 2020:** 14C30 (primary); 14C25, 14J70, 14K22, 14M25, 14E30, 65G40 (secondary)
- **Keywords:** Hodge conjecture; Fermat varieties; uniruled varieties; Fine interior; Abel–Jacobi map; coniveau; CM abelian varieties; Weil classes; motivated cycles
- **Abstract** (about 130 words; the Annals asks for at most about 200, self-contained and without citations): We prove the Hodge conjecture for the Fermat varieties of degrees 44, 51, 52 and 114 in every dimension, and more generally of every degree 2^a 3^b 11^c, every degree 2^a 3^b 13^c and every degree 2^a 3^b 19^c or 2^a 3^b 17^c with a ≤ 1, together with their products and the abelian varieties of Fermat type of these degrees. The key step is that the quotient of a Fermat threefold by the kernel of a suitable character is uniruled, by Batyrev's criterion for toric hypersurfaces; a second proof uses families of curves and a residue formula for their Abel–Jacobi maps. We also prove the Hodge conjecture for Fermat fourfolds of every odd degree, and determine which combinations of the standard conjectures around the Hodge conjecture imply it.

## The journal's AI policy

The Annals asks that authors be human and take full responsibility, that no AI be named as an author, and that "if an AI tool or LLM contributed an idea, authors should describe that idea and specify its location in the paper". The paper does this in Section 8, "A note on preparation". It lists the ideas the assistant proposed and where they appear, including the use of Batyrev's criterion and the homomorphism of Lemma 4.4. Read it and adjust it if your own account of the work differs.

## Declarations

The Annals form may not ask for these, but have them ready. Only you can confirm the first two.

- **Funding:** "The author received no funding for this work." Confirm this, or name the funder.
- **Competing interests:** "The author has no competing interests to declare." Confirm this.
- **Data and code:** "The source and the verification code are at https://github.com/creelie/e84hc and archived on Zenodo under the DOI 10.5281/zenodo.23234362 (this version: 10.5281/zenodo.23401546)."

## Before you press submit

- The PDF and tex.zip were built from release v1.8.0 with its version DOI on the title page. Every check passes in CI: Python, Julia and C agree on every finite step, including the block patterns of Corollary 4.28; both Lean projects build with standard axioms only, including the files for degrees 114, 44, 52 and 51 and the block patterns; the six interval certificates of the second proof pass at 1000 and 600 bits; and the Macaulay2 scripts pass.
- Read `../priority-check-2026-10-15.md` with the earlier checks of 11 October beside it. Together they record that, as of 15 October 2026, no one had proved the degrees 57, 33 or 39 without Kang's statement, no one had proved any degree divisible by 44, 52 or 51, and no one had stated the degrees 66, 78, 99, 117, 132 or 156.
- The proof of Theorem A uses no computer. Referees may still ask about the six interval certificates; they belong to the second proof, Appendix B describes them, and each program reruns in under a second.
- Suggested reviewers, if asked: specialists in algebraic cycles on Fermat varieties, toric hypersurfaces and abelian varieties of CM type. Avoid anyone you have collaborated with.
