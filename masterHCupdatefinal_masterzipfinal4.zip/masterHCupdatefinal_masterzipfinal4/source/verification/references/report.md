# Online check of paper/references.bib

Run on 2026-10-15 by `verification/references/check_references.py`.

| key | status | online record |
|---|---|---|
| ACGH85 | verified | Crossref: "Geometry of Algebraic Curves" (1985); title match 1.00 |
| Abd94 | verified | Crossref: "Algebraic Cycles in Families of Abelian Varieties" (1994, vol. 46, p. 1121-1134); title match 1.00 |
| And92 | verified | http://www.numdam.org/item/CM_1992__82_1_1_0/: HTTP 200, 6/6 title words on the page |
| And96 | verified | Crossref: "Pour une théorie inconditionnelle des motifs" (1996, vol. 83, p. 5-49); title match 0.99 |
| AS83 | verified | Crossref: "Generators of the Néron-Severi Group of a Fermat Surface" (1983, p. 1-12); title match 0.99 |
| AH62 | verified | Crossref: "Analytic cycles on complex manifolds" (1962, vol. 1, p. 25-45); title match 1.00 |
| BhH8 | verified | DataCite: "LaTeX source and verification code for the paper Algebraic Loci of Weil Classes on Abelian Varieties" (2026); title match 1.00 |
| BhHCF | verified | public GitHub repository holding paper/full_attempt.tex, checked with a web fetch on 2026-10-08 (record online: HTTP 200) |
| Blo72 | verified | Crossref: "Semi-regularity and de Rham cohomology" (1972, vol. 17, p. 51-66); title match 1.00 |
| BF03 | verified | Crossref: "A Semiregularity Map for Modules and Applications to Deformations" (2003, vol. 137, p. 135-210); title match 1.00 |
| CDK95 | verified | Crossref: "On the locus of Hodge classes" (1995, vol. 8, p. 483-506); title match 1.00 |
| CS14 | verified | arXiv 1101.3647: "Notes on absolute Hodge classes" by François Charles, Christian Schnell; title match 1.00 |
| Del71 | verified | Crossref: "Théorie de Hodge : II" (1971, vol. 40, p. 5-57); title match 0.97 |
| Del72 | verified | Crossref: "La conjecture de Weil pour les surfacesK3" (1971, vol. 15, p. 206-226); title match 0.99 |
| Del82 | verified | Crossref: "Hodge Cycles on Abelian Varieties" (1982, p. 9-100); title match 0.78 |
| daS21 | verified | Crossref: "Notes on the Hodge conjecture for Fermat varieties" (2021, vol. 2, p. e22); title match 1.00 |
| Fab88 | verified | Crossref: "Prym varieties of triple cyclic covers" (1988, vol. 199, p. 61-79); title match 1.00 |
| FF26 | verified | Crossref: "The Hodge conjecture for Weil fourfolds with discriminant 1 via singular OG6-varieties" (2026, vol. 210, p. 103876); title match 1.00 |
| Ful98 | verified | Crossref: "Intersection Theory" (1998); title match 1.00 |
| Gri69 | verified | Crossref: "On the Periods of Certain Rational Integrals: I" (1969, vol. 90, p. 460); title match 1.00 |
| Gro69 | verified | nLab references: Algebraic Geometry (Bombay, 1968), Oxford Univ. Press, pp. 193-199 (record online: HTTP 200) |
| Hod52 | verified | scan of the ICM 1950 Proceedings, vol. 1 (AMS, 1952): the address starts on p. 182, and the next one (Hopf) on p. 193 (record online: HTTP 200) |
| Hor74 | verified | Crossref: "On deformations of holomorphic maps II" (1974, vol. 26); title match 1.00 |
| IM13 | verified | Crossref: "Semiregularity and obstructions of complete intersections" (2013, vol. 235, p. 92-125); title match 1.00 |
| Jum26 | verified | arXiv 2608.18134: "The Hodge conjecture for Fermat fourfolds of odd degree at most 199" by Rifat Jumagulov; title match 1.00 |
| Kle68 | verified | nLab references and Open Library: Dix exposes sur la cohomologie des schemas, North-Holland, 1968, pp. 359-386, MR0292838 (record online: HTTP 200) |
| Kle94 | verified | Crossref: "The standard conjectures" (1994, p. 3-20); title match 1.00 |
| KR78 | verified | Crossref: "Simple Factors in the Jacobian of a Fermat Curve" (1978, vol. 30, p. 1183-1205); title match 1.00 |
| KS53 | verified | Crossref: "Divisor Class Groups on Algebraic Varieties" (1953, vol. 39, p. 872-877); title match 1.00 |
| Koi04 | verified | Crossref: "Algebraicity of some Weil Hodge Classes" (2004, vol. 47, p. 566-572); title match 1.00 |
| Kol92 | verified | Crossref: "Trento examples" (1992, p. 134-139); title match 1.00 |
| Kol96 | verified | Crossref: "Rational Curves on Algebraic Varieties" (1996); title match 1.00 |
| KuS67 | verified | Crossref: "Abelian varieties attached to polarizedK 3-surfaces" (1967, vol. 169, p. 239-242); title match 0.99 |
| LO11 | verified | Crossref: "Prym varieties of cyclic coverings" (2011, vol. 150, p. 391-403); title match 1.00 |
| Lef24 | verified | Internet Archive and Open Library: S. Lefschetz, L'analysis situs et la geometrie algebrique, Gauthier-Villars, 1924 (record online: HTTP 200) |
| Lie68 | verified | Crossref: "Numerical and Homological Equivalence of Algebraic Cycles on Hodge Manifolds" (1968, vol. 90, p. 366); title match 1.00 |
| Loo97 | verified | Crossref: "Prym Representations of Mapping Class Groups" (1997, vol. 64, p. 69-83); title match 1.00 |
| Mar25a | verified | arXiv 2502.03415: "Cycles on abelian 2n-folds of Weil type from secant sheaves on abelian n-folds" by Eyal Markman; title match 1.00 |
| Mar25b | verified | arXiv 2509.23403: "Secant sheaves and Weil classes on abelian varieties" by Eyal Markman; title match 1.00 |
| Mat59 | verified | Crossref: "On a characterization of a Jacobian variety" (1959, vol. 32); title match 1.00 |
| Mil20 | verified | arXiv 2010.08857: "Hodge classes on abelian varieties" by James S. Milne; title match 1.00 |
| Mum74 | verified | Crossref: "Prym Varieties I" (1974, p. 325-350); title match 1.00 |
| Mum69 | verified | Crossref: "A note of Shimura's paper ?discontinuous groups and abelian varieties?" (1969, vol. 181, p. 345-351); title match 1.00 |
| OAI26 | verified | listed in CONTENTS.md of github.com/openai/math as preprints/The-rational-Hodge-conjecture-for-CM-abelian-varieties-October-6-2026/paper.pdf (record online: HTTP 200) |
| PST21 | verified | arXiv 2109.08788: "Canonical Heights on Shimura Varieties and the André-Oort Conjecture" by Jonathan Pila, Ananth N. Shankar, Jacob Tsimerman, Hélène Esnault, Michael Groechenig; title match 0.99 |
| PZ25 | verified | Crossref: "Algebraicity of Hodge classes on some generalized Prym varieties" (2027, vol. 712, p. 101-122); title match 1.00 |
| Ran80 | verified | http://www.numdam.org/item/CM_1980__42_1_121_0/: HTTP 200, 3/3 title words on the page |
| Ran81 | verified | Crossref: "On subvarieties of abelian varieties" (1980, vol. 62, p. 459-479); title match 1.00 |
| Sch88 | verified | http://www.numdam.org/item/CM_1988__65_1_3_0/: HTTP 200, 6/6 title words on the page |
| Sch98 | verified | Crossref: "Addendum to: Hodge Classes on Self-Products of a Variety with an Automorphism" (1998, vol. 114, p. 321-328); title match 1.00 |
| Shi79 | verified | Crossref: "The hodge conjecture for Fermat varieties" (1979, vol. 245, p. 175-184); title match 1.00 |
| SK79 | verified | Crossref: "On Fermat varieties" (1979, vol. 31); title match 1.00 |
| vG94 | verified | Crossref: "An Introduction to the Hodge Conjecture for Abelian Varieties" (1994, p. 233-252); title match 1.00 |
| Voi02 | verified | Crossref record without title: author Voisin, 2002, p. 1057, International Mathematics Research Notices |
| Voi02b | verified | Crossref: "Hodge Theory and Complex Algebraic Geometry I" (2002); title match 1.00 |
| Wei52 | verified | Crossref: "Jacobi sums as “Grössencharaktere”" (1952, vol. 73, p. 487-495); title match 0.98 |
| Wei77 | verified | Crossref: "Abelian varieties and the Hodge ring" (1979, p. 1468-1476); title match 1.00; page 1468-1476 vs 421--429 |
| EFS25 | verified | arXiv 2507.15704: "Matroids and the integral Hodge conjecture for abelian varieties" by Philip Engel, Olivier de Gaay Fortman, Stefan Schreieder; title match 1.00 |
| Hir64 | verified | Crossref: "Resolution of Singularities of an Algebraic Variety Over a Field of Characteristic Zero: I" (1964, vol. 79, p. 109); title match 1.00 |
| MFK94 | verified | Crossref: "Geometric Invariant Theory" (1994); title match 1.00 |
| OAI26b | verified | listed in CONTENTS.md of github.com/openai/math as preprints/Abelian-covers-Gale-correspondences-and-the-Hodge-conjecture-for-powers-October-6-2026/paper.pdf (record online: HTTP 200) |
| OAI26c | verified | listed in CONTENTS.md of github.com/openai/math as preprints/Weil-classes-and-Hodge-classes-on-abelian-powers-October-6-2026/paper.pdf (record online: HTTP 200) |
| MZ99 | verified | Crossref: "Hodge classes on abelian varieties of low dimension" (1999, vol. 315, p. 711-733); title match 1.00 |
| Aok83 | verified | Crossref: "On some arithmetic problems related to the hodge cycles on the fermat varieties" (1983, vol. 266, p. 23-54); title match 1.00 |
| Aok00 | verified | JaLC: "Some Remarks on the Hodge Conjecture for Abelian Varieties of Fermat Type" (2000, vol. 49, p. 177); title match 1.00 |
| Pet26 | verified | DataCite: "The Hodge conjecture for Fermat varieties of degree 35" (2026); title match 1.00 |
| Aok87 | verified | Crossref: "Some new algebraic cycles on Fermat varieties" (1987, vol. 39, p. 385-396); title match 1.00 |
| Kan15 | verified | Crossref: "Refined Motivic Dimension" (2015, vol. 58, p. 519-529); title match 1.00 |
| Kan16 | verified | Crossref: "REFINED MOTIVIC DIMENSION OF SOME FERMAT VARIETIES" (2016, vol. 93, p. 223-230); title match 1.00 |
| MMRV26 | verified | arXiv 2609.27301: "Lengths of Hodge characters in Fermat varieties" by Maximiliano Miranda, Hossein Movasati, Lucas Rufino, Roberto Villaflor; title match 1.00 |
| Was97 | verified | Crossref: "Introduction to Cyclotomic Fields" (1997); title match 1.00 |
| vG08 | verified | Crossref: "Real multiplication on K3 surfaces and Kuga Satake varieties" (2008, vol. 56, p. 375-399); title match 1.00 |
| Sch10 | verified | Crossref: "The Hodge conjecture for self-products of certain K3 surfaces" (2010, vol. 324, p. 507-529); title match 1.00 |
| vGS25 | verified | Crossref: "On families of K3 surfaces with real multiplication" (2025, vol. 13, p. e2); title match 1.00 |
| Var23 | verified | Crossref: "Hodge similarities, algebraic classes, and Kuga–Satake varieties" (2023, vol. 305, p. 69); title match 1.00 |
| BvGS24 | verified | arXiv 2401.04072: "K3 surfaces with real or complex multiplication" by Eva Bayer-Fluckiger, Bert van Geemen, Matthias Schütt; title match 1.00 |
| Bus19 | verified | Crossref: "Every rational Hodge isometry between two K⁢3K3 surfaces is algebraic" (2019, vol. 755, p. 127-150); title match 0.98 |
| Huy19 | verified | Crossref: "Motives of isogenous K3 surfaces" (2019, vol. 94, p. 445-458); title match 1.00 |
| Kra69 | verified | Crossref: "Newton-Algorithmen zur Bestimmung von Nullstellen mit Fehlerschranken" (1969, vol. 4, p. 187-201); title match 1.00 |
| Moo77 | verified | Crossref: "A Test for Existence of Solutions to Nonlinear Systems" (1977, vol. 14, p. 611-615); title match 1.00 |
| Joh17 | verified | Crossref: "Arb: Efficient Arbitrary-Precision Midpoint-Radius Interval Arithmetic" (2017, vol. 66, p. 1281-1292); title match 1.00 |
| Neu90 | verified | Crossref: "Interval Methods for Systems of Equations" (1991); title match 1.00 |
| EGA43 | verified | Crossref: "Éléments de géométrie algébrique : IV. Étude locale des schémas et des morphismes de schémas, Troisième partie" (1966, vol. 28, p. 5-255); title match 0.91 |
| Har77 | verified | Crossref: "Algebraic Geometry" (1977); title match 1.00 |
| CG80 | verified | cited as [4] in Carlson, Green, Griffiths and Harris, Compositio Math. 50 (1983): Journees de geometrie algebrique d'Angers, Sijthoff and Noordhoff (1980) 51-76 (record online: HTTP 200) |
| Jum26b | verified | DataCite: "The Hodge conjecture for Fermat fourfolds: odd degrees up to 199 and the even-degree census to 250 — papers, exact certificates and verifiers" (2026); title match 1.00 |
| Del74 | verified | Crossref: "Théorie de Hodge : III" (1974, vol. 44, p. 5-77); title match 0.98 |
| Bat23 | verified | Crossref: "Canonical models of toric hypersurfaces" (2023, p. 394-431); title match 1.00 |
| Bat24 | verified | Crossref: "Projecting Lattice Polytopes According to the Minimal Model Program" (2024, p. 1-21); title match 1.00 |
| MM86 | verified | Crossref: "A Numerical Criterion for Uniruledness" (1986, vol. 124, p. 65); title match 1.00 |
| Miy88 | verified | Crossref: "On the Kodaira dimension of minimal threefolds" (1988, vol. 281, p. 325-332); title match 1.00 |
| Mor88 | verified | Crossref: "Flip theorem and the existence of minimal models for 3-folds" (1988, vol. 1, p. 117-253); title match 1.00 |

92 entries, 0 need attention.
