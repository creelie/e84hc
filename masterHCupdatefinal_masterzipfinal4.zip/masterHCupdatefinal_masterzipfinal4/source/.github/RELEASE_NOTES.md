**On the Hodge conjecture for Fermat varieties**
Deep Bhattacharjee. Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India.
d.bhattacharjee@erl-forschung.de · itsdeep@live.com · ORCID [0000-0003-0466-750X](https://orcid.org/0000-0003-0466-750X)

The paper proves the Hodge conjecture for the Fermat varieties of degrees 33, 39, 44, 51, 52 and 114 in every dimension, and more generally of every degree 2^a 3^b 11^c, every degree 2^a 3^b 13^c and every degree 2^a 3^b 19^c or 2^a 3^b 17^c with a ≤ 1, together with their products and the abelian varieties of Fermat type of these degrees (Theorem A). For the degrees divisible by 44 (44, 88, 176, 352, 484, …), by 52 (52, 104, 208, 416, 676, …) or, among the 2^a 3^b 17^c with a ≤ 1, by 51 (51, 102, 153, 306, 459, …) the theorem had not been proved before; the 2026 preprint of Miranda, Movasati, Rufino and Villaflor treats every degree below 65 except 44, 51 and 52. For the degrees divisible by 57 it is the first proof that does not rest on a statement of Kang whose proof has a gap; the only earlier argument, for degree 57, does. The same holds for 33 and 39, and the degrees 66, 78, 99, 117, 132, 156, … divisible by 33 or 39 are stated here for the first time. For 114, 171, 342, 513, … the theorem had not been stated before. The proof of Theorem A uses no computer: its key step, that certain quotients of Fermat threefolds are uniruled, follows from Batyrev's criterion and block patterns checked by hand. Six certified computations in interval arithmetic (Propositions 4.30, 4.33, 4.36, 4.38, 4.41 and 4.43) give a second proof of that step.

It also proves the Hodge conjecture for Fermat fourfolds of every odd degree (Theorem B), determines which combinations of the standard statements around the Hodge conjecture imply it (Theorems C and D), and proves the conditional and partial results of earlier versions (Theorems E, F and G).

**The Hodge conjecture itself is not proved.** Section 8 of the paper lists what is proved, what is proved under a stated hypothesis, and what remains open.

### Files

- `on-the-hodge-conjecture-for-fermat-varieties.pdf`: the paper, 83 pages, `amsart`.
- `on-the-hodge-conjecture-for-fermat-varieties-tex.zip`: the full LaTeX source, with the figures as PNG and their TikZ sources.
- `on-the-hodge-conjecture-for-fermat-varieties-arxiv.tar.gz`: the arXiv submission, containing `main.tex`, `sections/`, `main.bbl` and the PNG figures. It compiles with pdflatex alone.

The workflow attaches these files to the release once the paper has been built on GitHub.

### Checks

`verification/shell/run_all.sh` re-runs the finite steps:

- `closure_checks` in Python, Julia and C, in exact arithmetic, with identical 218-line outputs;
- a Lean 4 file that uses the core library only, with no `sorry` and no `native_decide`;
- a Lean 4 project with Mathlib (`verification/lean-mathlib`) that proves the classification of Hodge characters behind Theorem B, including B₁,χ ≠ 0, the finite and algebraic steps for degrees 114, 44, 52 and 51, the block patterns, and the parity ν_R at levels 33 and 39; its 45 main theorems use only the standard axioms;
- exhaustive searches of the Hodge characters of Fermat surfaces and fourfolds, in C, Python and Julia;
- `fermat114` in Python, Julia and C, the lattice computation of [B₁₁₄ : S₁₁₄], family I in sympy, and the Arb certificate for family II at 1000 and 600 bits;
- `fermat44` in Python, Julia and C, with identical 14-line outputs, the lattice computation B₄₄ = S₄₄ + Z[β], the Arb certificate for the family of degree 11 at 1000 and 600 bits, and a contour integral that reproduces its residue to 15 digits;
- `fermat52` in Python, Julia and C, with identical 20-line outputs, the lattice computation B₅₂ = S₅₂ + Z[β], the Arb certificates for the families of degrees 14 and 5 at 1000 and 600 bits, and contour integrals that reproduce both residues to 15 digits;
- `fermat51` in Python, Julia and C, with identical 19-line outputs, the lattice computation B₁₀₂ = S₁₀₂ + Z[β], the Arb certificates for the families of degrees 6 and 18 at 1000 and 600 bits, and contour integrals that reproduce both residues to 15 digits;
- `patterns` in Python, Julia and C, with identical 10-line outputs: the seven block patterns and the parity ν_R at levels 33 and 39;
- Macaulay2 scripts for the Jacobian-ring Hodge numbers and Max Noether's theorem.

All 92 references were checked online against an online record (`verification/references/report.md`).

### Citation and DOI

Concept DOI, covering all versions: [10.5281/zenodo.23234362](https://doi.org/10.5281/zenodo.23234362). Zenodo gives each release its own version DOI under it: v1.0.0 is [10.5281/zenodo.23234363](https://doi.org/10.5281/zenodo.23234363), v1.0.1 is [10.5281/zenodo.23234501](https://doi.org/10.5281/zenodo.23234501), v1.0.2 is [10.5281/zenodo.23236587](https://doi.org/10.5281/zenodo.23236587), v1.1.0 is [10.5281/zenodo.23271115](https://doi.org/10.5281/zenodo.23271115), v1.2.0 is [10.5281/zenodo.23272739](https://doi.org/10.5281/zenodo.23272739), v1.3.0 is [10.5281/zenodo.23272887](https://doi.org/10.5281/zenodo.23272887), v1.4.0 is [10.5281/zenodo.23288228](https://doi.org/10.5281/zenodo.23288228), v1.5.0 is [10.5281/zenodo.23289125](https://doi.org/10.5281/zenodo.23289125), v1.6.0 is [10.5281/zenodo.23289930](https://doi.org/10.5281/zenodo.23289930), v1.7.0 is [10.5281/zenodo.23292094](https://doi.org/10.5281/zenodo.23292094), and this release, v1.8.0, is [10.5281/zenodo.23401546](https://doi.org/10.5281/zenodo.23401546).

### What is new in this version

- **The proof of Theorem A no longer uses a computer.** Section 4.5 proves the coniveau step by hand. Each piece of H³ that the proof needs lives on the quotient of the Fermat threefold by the kernel of a character. This quotient is birational to a hypersurface in a torus whose Newton polytope is a simplex. A block pattern (Definition 4.23), a small table of integers checked by hand, shows that the Fine interior of the simplex is empty (Lemma 4.24). By Batyrev's criterion the quotient then has negative Kodaira dimension, so it is uniruled (Mori, Miyaoka, Miyaoka–Mori), and its H³ has coniveau one (Theorem 4.25). Corollary 4.28 gives a block pattern for each of the seven characters needed in degrees 114, 44, 52 and 51. Proposition 4.27 joins the pieces through Deligne's description of classes supported on a divisor and the Lefschetz (1,1) theorem. The families of curves and the six Arb certificates remain as a second proof.
- Remark 4.26 shows that the converse holds (empty Fine interior gives a block pattern). It also explains where the method stops. In every pair of characters that the searches found for degree 110, one character has a "shadow", a non-unit t with Σ⟨tα_k⟩ = m, which gives an interior lattice point; that character has no block pattern, and its quotient has nonnegative Kodaira dimension. Degree 110 stays open.
- Theorem A now also covers the degrees 2^a 3^b 11^c and 2^a 3^b 13^c, in particular 33, 39, 66, 78, 99, 117, 132 and 156. In degrees 33 and 39 the class left by Aoki's reduction is the exceptional character O₃₃ or O₃₉, algebraic by Lemma 3.26. Lemma 4.4 shows that it is not reached by linear subspaces and Aoki's cycles, through the parity of the number of elements of square 1. Degree 12 comes from Aoki's theorem.
- New checks: `patterns` in Python, Julia and C, and `Patterns.lean` (seven more theorems in `Axioms.lean`).

### What v1.7.0 added (numbering as in v1.7.0)

- Theorem A now also covers every degree 2^a 3^b 17^c with a ≤ 1, in particular the degree 51. With 44 and 52 from earlier versions, this covers the three degrees below 65 that the preprint of Miranda, Movasati, Rufino and Villaflor leaves out. At level 102 Aoki's reduction leaves one class, a balanced multiset β of ten residues with exactly one residue of order 17 (Corollary 4.5, which now also treats 102). No balanced multiset of four or six residues modulo 102 has an odd number of residues of order 17, and a lattice computation gives B₁₀₂ = S₁₀₂ + Z[β] without Aoki's theorem.
- β is the join of the threefold characters α = (1, 7, 51, 60, 85) and α′ = (91, 34, 26, 98, 57), whose types are complementary for every unit (Lemma 4.30).
- A block family of degree 6 for 37α′ = (1, 34, 44, 56, 69) (Proposition 4.31, Corollary 4.32) and one of degree 18 for 5α = (5, 35, 51, 96, 17) (Proposition 4.33, Corollary 4.34) have nonzero residues, certified in Arb (Appendix B). Remark 4.38 records what was known and gives a counting obstruction to block families, which explains why none was found for the class left in degree 110.
- New checks: `fermat51` in Python, Julia and C, `Degree51.lean` (seven more theorems in `Axioms.lean`), `family51_certificate.py` and `family51_contour.py`.

### What v1.6.0 added (numbering as in v1.6.0)

- Theorem A now also covers every degree 2^a 13^b. In degree 52 Aoki's reduction leaves one class, a balanced multiset β of ten residues with exactly one residue of order 13 (Corollary 4.5, which now treats 44, 52 and 114 together). An enumeration shows that no balanced multiset of four or six residues modulo 52 has an odd number of residues of order 13, and a lattice computation gives B₅₂ = S₅₂ + Z[β] without Aoki's theorem.
- β is the join of the threefold characters α = (1, 5, 16, 37, 45) and α′ = (29, 18, 42, 50, 17), whose types are complementary for every unit (Lemma 4.25). Both pieces of H³ need families of curves.
- A block family of degree 14 for α (Proposition 4.26, Corollary 4.27) and one of degree 5 for 9α′ = (1, 6, 14, 34, 49) (Proposition 4.28, Corollary 4.29) have nonzero residues, certified in Arb (Appendix B). Remark 4.32 records what was known: Aoki covers the degrees 2^a 13^b not divisible by 52, and the preprint of Miranda, Movasati, Rufino and Villaflor excludes 52.
- New checks: `fermat52` in Python, Julia and C, `Degree52.lean` (seven more theorems in `Axioms.lean`), `family52_certificate.py` and `family52_contour.py`.

### What v1.5.0 added (numbering as in v1.5.0)

- Theorem A now also covers every degree 2^a 11^b. In degree 44 Aoki's reduction leaves one class, a balanced multiset β of eight residues with exactly one residue of order 11 (Corollary 4.5, which now treats 44 and 114 together). An enumeration shows that no balanced multiset of four or six residues modulo 44 has this property, so β is the first class in degree 44 that linear subspaces and Aoki's cycles miss.
- β is the join of the threefold character α = (1, 5, 8, 33, 41) and the curve character b = (9, 37, 42), whose types are complementary for every unit (Lemma 4.22). Proposition 4.18 joins a threefold character that is carried by curves with any curve character of complementary type, through the Lefschetz (1,1) theorem on a product of two curves and Shioda's inductive structure with r = 4, s = 2.
- A block family of degree 11 for α (Proposition 4.23, Corollary 4.24) has a nonzero residue, certified in Arb (Appendix B). Remark 4.26 records what was known: Aoki covers the degrees 2^a 11^b not divisible by 44, and the preprint of Miranda, Movasati, Rufino and Villaflor excludes 44.
- New checks: `fermat44` in Python, Julia and C, `Degree44.lean`, `family44_certificate.py` and `family44_contour.py`.

### What v1.4.0 added (numbering as in v1.4.0)

- A new Section 4 proves Theorem A. Aoki's reduction leaves one class in degree 114, a balanced multiset of ten residues with one residue of order 19 (Corollary 4.5). It is the join of two characters of the Fermat threefold of degree 114 with complementary level-one Hodge structures (Lemma 4.6). Each is shown to be carried by curves through a residue formula for the derivative of the Abel–Jacobi map of a family of curves, which extends Peterson's method to "block families" (Theorem 4.16). The family for the first character, of cubic forms, is computed by hand (Proposition 4.18); the family for the second has degree 24 and is certified in Arb (Proposition 4.19, Appendix B).
- The paper is reframed around this theorem: new title, abstract and introduction, with the main theorems relettered A to G. Section 8 now says which ideas came from the AI assistant and where, as the Annals of Mathematics policy asks.
- Remark 4.21 places the theorem: the even-degree census of Fermat fourfolds up to 250 now leaves only the degrees 110 and 220 open.
- Eight references were added, all verified online.

### What v1.3.0 added

- Proposition 6.17 (5.17 in v1.3.0) describes Schoen's subvariety Y as a component of a Prym–Brill–Noether locus, smooth of dimension n at its general point; for étale double covers the same locus gives Mumford's Prym theta divisor. Question 6.14 stays open.

### What v1.2.0 added (its Theorem F is Theorem B now, and its Sections 4 to 7 are Sections 5 to 8)

- Theorem F now covers every odd degree m. A new subsection, Section 3.7, treats odd m divisible by 3. Every Hodge sextuple that generates Z/m and contains no pair a, −a has a move: one of Aoki's cycles trades it for a quadruple, whose classes are known, or for a sextuple of smaller orders. The only exceptions are three characters, in degrees 21, 33 and 39 (Theorem 3.27). Identities on the Fermat fourfolds of degrees 21, 66 and 78 close them (Lemma 3.26). The proof is by hand.
- The theorem is new for the odd degrees m > 199 that are divisible by 3 or 5 and have a prime factor larger than 7. The first are 201, 205, 207, 213 and 215. Remark 3.7 now also cites Aoki's 2000 theorem on abelian varieties of Fermat type and Peterson's 2026 preprint on degrees 2^a 3^b 5^c 7^d.
- New checks:
  - `fermat_odd` in Python, Julia and C lists every Hodge sextuple in odd degrees divisible by 3 and finds a move for each. The three programs agree up to degree 63, and the C program reaches degree 105.
  - `Closure.lean` checks the three exceptional characters and their identities by `decide`.
  - The induction itself is not formalized in Lean.
- Section 7 cites Varesco's theorem (Math. Z. 2023) for the general member of the first four-dimensional families of K3 surfaces with real multiplication, next to the families of van Geemen and Schütt.
- The reference checker also asks the Japan Link Center, and all 77 references verify.

### What v1.1.0 added

- Theorem F: the Hodge conjecture holds for the Fermat fourfold of every degree m prime to 6. The proof shows that every Hodge character contains two entries a and −a, or is (x, x+m/5, x+2m/5, x+3m/5, x+4m/5, −5x) up to order (Theorem 3.9). Classes of the first kind come from linear subspaces through Shioda and Ran's inductive structure, and those of the second kind from Aoki's cycles, pulled back along a covering of Fermat fourfolds. The only analytic input is B₁,χ ≠ 0 for odd primitive characters χ.
- The theorem is new when 5 divides m, m > 199 and m is not a power of 5 (first cases 205, 215, 235). Smaller degrees were settled by computer searches, and other degrees prime to 6 by Aoki. Remark 3.21 shows that a step in Kang's proof of the general statement fails.
- The classification is proved in Lean 4 with Mathlib, and so is B₁,χ ≠ 0, derived from Mathlib's L(1, χ) ≠ 0 through the Gauss sum and the logarithmic series. Only the geometric input stays a hypothesis there. The classification is also re-checked by exhaustive search up to degree 125.
- Section 7 now describes the first open case of (F3′) precisely: the square of a very general K3 surface with real multiplication, whose maximal families have Picard number 2 and dimension 8.

Sections 2 and 4 to 6 are unchanged from v1.0.2.
