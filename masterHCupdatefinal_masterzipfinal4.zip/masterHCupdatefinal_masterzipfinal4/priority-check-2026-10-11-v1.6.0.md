# Priority check for Theorem A, 11 October 2026 (about 00:32 UTC)

Theorem A of "On the Hodge conjecture for Fermat varieties" proves the Hodge conjecture for the Fermat varieties of degree m = 2^a 11^b, m = 2^a 13^b, and m = 2^a 3^b 19^c with a ≤ 1, in every dimension, for their products and for the abelian varieties of Fermat type of these degrees. Release v1.4.0 added the degrees divisible by 57, release v1.5.0 those divisible by 44 (both checked on 10 October 2026, at about 21:15 and 23:01 UTC), and release v1.6.0 adds those divisible by 52. Before release v1.6.0 we checked again whether anyone had already proved these cases.

| Source | Query | Finding |
|---|---|---|
| arXiv (API, newest first) | `all:Fermat AND all:Hodge`; `abs:Fermat AND abs:Hodge AND abs:52` | Nothing new since the last check. The newest relevant paper is still Miranda, Movasati, Rufino and Villaflor, arXiv 2609.27301v2 (23 Sept 2026), which states the Hodge conjecture for degree d < 65 with d ≠ 44, 51, 52, so it excludes 52. Next are 2609.12759 (Chern characters on hypersurfaces) and Jumagulov, 2608.18134 (odd fourfolds up to 199). |
| Zenodo (API) | "Fermat AND Hodge", "Fermat AND 52 AND Hodge" | Our own release v1.5.0 (10.5281/zenodo.23289125); Peterson's degree 35 (10.5281/zenodo.22945544); Saller, "The Hodge conjecture for sums of binary quartics" (10.5281/zenodo.23287572, 10 Oct 2026), which treats hypersurfaces F_0(u_0,v_0) + … + F_m(u_m,v_m) = 0 with binary quartics F_i, so degree 4, not 52; and unrelated claims. Jumagulov's census of even-degree fourfolds (10.5281/zenodo.21670577) treats fourfolds only (Remark 4.31). |
| github.com/openai/math, CONTENTS.md | "Fermat", "Hodge" | No Fermat-variety result. Result 032 claims the rational Hodge conjecture for CM abelian varieties. That claim would imply it for every Fermat variety (Theorem E of our paper), but it is unrefereed, and Theorem A does not use it. |
| Palomar registry (data.palomar-registry.org/api/v1/results, revision 216) | `q=Fermat`, `q=Hodge` | No entry on Hodge classes of Fermat varieties. The Fermat entry is the generalized Fermat equation x² + y⁵ = z⁷; the Hodge entries are Markman's Weil classes on abelian sixfolds and two unrelated results. |
| OpenRefute (the-omega-institute/trureturing at 7eabc72, 11 Oct 2026) | file names containing "Hodge" or "Fermat" | No problem on Hodge classes or Fermat varieties; the matches are Fermat primes, Fermat's little theorem, a combinatorial-Hodge-theory reference and Anthropic's Lean proof of Fermat's Last Theorem. |
| ProbXiv | "Fermat Hodge" | Not reachable from this network (refused by the proxy at the previous check). |

Conclusion:

- For 52 | m (52, 104, 208, 416, 676, …), Theorem A is the first proof. The only other source that would cover these degrees is the unrefereed CM claim in github.com/openai/math.
- For 44 | m, Theorem A is likewise the first proof.
- For 57 | m, Theorem A is the first proof that does not rest on Kang's statement, and for 114, 171, 342, 513, … no earlier work states the theorem.
- Below degree 65, degree 51 is the one degree still without a proof in every dimension (Jumagulov covers its fourfold). Theorem A does not cover it.
