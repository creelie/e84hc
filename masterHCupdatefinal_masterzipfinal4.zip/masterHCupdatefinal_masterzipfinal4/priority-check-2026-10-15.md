# Priority check, 15 October 2026 (about 17:05 UTC)

Made before release v1.8.0 of creelie/e84hc. It covers the two new points of
that version:

1. a proof of the coniveau step of Theorem A by Batyrev's criterion for
   hypersurfaces in tori (block patterns, uniruled quotients); and
2. the degrees 2^a 3^b 11^c and 2^a 3^b 13^c, among them 33, 39, 66, 78, 99,
   117, 132 and 156.

## Searches

- arXiv API, all fields "Hodge conjecture" AND "Fermat", newest first. The
  newest entries are Miranda–Movasati–Rufino–Villaflor, "Lengths of Hodge
  characters in Fermat varieties" (2609.27301v2, 23 Sep 2026), a paper on
  Chern characters of sheaves on hypersurfaces (2609.12759, 11 Sep 2026), and
  Petersen's odd fourfolds up to 199 (2608.18134, 28 Jul 2026). Nothing has
  appeared since the check of 11 October.
- Zenodo API, "Hodge conjecture" AND Fermat, newest first. The new records
  since 11 October are by Saller (with Claude):
  - 23287572, sums of binary quartics;
  - 23287272, powers of very general split quintic and sextic hypersurfaces;
  - 23325022, sextic fourfolds of a family of K3 surfaces;
  - 23329273, very general sums of binary quintics and sextics;
  - 23329495, very general F(x)+F(y)=0;
  - 23378313, cyclic symmetry and F(x)+F(y)=0.

  Each treats sums of binary forms of degree at most 6, or very general
  members of families. None treats a Fermat variety of degree 33, 39 or
  their multiples, and none uses uniruled quotients. The other new records
  are framework texts that claim the full conjecture without proofs.
- Web search for "Hodge conjecture Fermat uniruled quotient Batyrev Fine
  interior". It found no use of Batyrev's Fine interior or of uniruled
  quotients for the Hodge conjecture on Fermat varieties.

## What the literature already has for these degrees

- Aoki: every degree 2^a 3^b (his theorem for 12, Theorem 0.1 of his 2000
  paper), and the degrees 2^a 11^b and 2^a 13^b not divisible by 44 or 52.
- Miranda–Movasati–Rufino–Villaflor (2609.27301): every degree below 65
  except 44, 51 and 52, so 33 and 39 are stated there. Their reduction ends
  with a statement of Kang about the Fermat fourfold whose proof has a gap
  (Remark 3.21 of the paper). The proof in v1.8.0 does not use it. For 33
  it uses the identity of Jumagulov's Theorem 1.4 (cited); for 39 it uses an
  identity at level 78; and in both cases the parity ν_R of Lemma 4.4.
- Jumagulov's census, with Peterson's divisor 35, leaves the even fourfold
  degrees 110, 114, 220 and 228 up to 250, and Theorem A settles 114 and
  228. The census is a statement about fourfolds only; Theorem A covers
  every dimension.

## Conclusion

For the degrees divisible by 33 or 39 other than 33 and 39 (66, 78, 99, 117,
132, 156, …) the Hodge conjecture for Fermat varieties in every dimension is
stated here for the first time. For 33 and 39 it is the first proof that
does not rest on Kang's statement. The proof of the coniveau step by
Batyrev's criterion is new as far as these searches show.
