# masterHCupdatefinal_masterzipfinal4.zip: e84hc release v1.8.0

Deep Bhattacharjee, "On the Hodge conjecture for Fermat varieties", 83 pages.

Repository: https://github.com/creelie/e84hc. Concept DOI covering all versions: 10.5281/zenodo.23234362. Release v1.8.0: 10.5281/zenodo.23401546. Source in `source/` is the repository at commit 567a805d33a8, the tree that `main` carries with this zip (the folder `sources/` left out).

## What the paper proves

Theorem A proves the Hodge conjecture for the Fermat varieties of degree m = 2^a 3^b 11^c, m = 2^a 3^b 13^c, and m = 2^a 3^b 19^c or m = 2^a 3^b 17^c with a ≤ 1, in every dimension, for their products and for the abelian varieties of Fermat type of these degrees. For degrees divisible by 44 (44, 88, 176, …), by 52 (52, 104, 208, …) or by 51 (51, 102, 153, 306, 459, …) it is the first proof. For degrees divisible by 57, 33 or 39 it is the first proof that does not rest on Kang's statement about Fermat fourfolds, whose proof has a gap (Remark 3.21), and the degrees 66, 78, 99, 117, 132, 156, … are stated for the first time.

The paper also proves Theorems B to G of the earlier versions. It does not prove the Hodge conjecture. Section 8 lists what is proved, what is proved under a stated hypothesis, and what is open.

## What is new in v1.8.0

The proof of Theorem A is now entirely analytical. No step of it uses a computer.

- The key step is that a level-one piece of H^3 of a Fermat threefold is supported on a divisor. Section 4.5 proves it by birational geometry. The piece lives on the quotient of the threefold by the kernel K of its character. On the torus this quotient is a hypersurface whose Newton polytope is a simplex, and by Batyrev's theorem it has negative Kodaira dimension when the Fine interior of the simplex is empty. A block pattern, a small table of integers with a few linear conditions and one inequality (Definition 4.23), makes the Fine interior empty (Lemma 4.24). The quotient is then uniruled by Mori, Miyaoka and Miyaoka–Mori, so its H^3 has coniveau one (Theorem 4.25), and Deligne's description of classes on a divisor with the Lefschetz (1,1) theorem makes the join algebraic (Proposition 4.27).
- Corollary 4.28 writes out the seven block patterns needed for the degrees 114, 44, 52 and 51. Each is checked by hand in a few lines.
- The families of curves and the six interval certificates of v1.7.0 stay in the paper as a second proof of the same step.
- Theorem A now also covers 2^a 3^b 11^c and 2^a 3^b 13^c, among them 33, 39, 66, 78, 99, 117, 132 and 156. For 33 and 39 the class left by Aoki's reduction is an exceptional sextuple, algebraic by an explicit identity, and Lemma 4.4 shows that Aoki's cycles do not reach it: it contains an odd number of square roots of 1.
- Remark 4.26 proves the converse (an empty Fine interior always gives a block pattern) and shows why the method stops at the degree 110: in every pair of characters the searches found there, one character has a "shadow", which puts a lattice point in the Fine interior.

## What is still open

- The Hodge conjecture itself, for Fermat varieties and in general. Nobody has a proof, and this paper does not claim one.
- Among Fermat varieties, the first degrees not covered without Kang's statement are those whose class comes from the divisor 55, beginning with 110 and 220 for the fourfolds. Remark 4.26(b) explains why both methods of the paper fail there.

## Is it an Annals paper?

In my judgment, still no, although it is stronger than v1.7.0. Theorem A now has a computer-free proof, by a new method (birational geometry of toric quotients), for six of the finitely many classes left by Aoki's reduction: 44, 52 and 51 for the first time, and 57, 33 and 39 without Kang's statement. But it does not change what is known about the Hodge conjecture in general, and the Annals rarely takes papers of this kind. Mathematische Annalen or Compositio Mathematica is the realistic target. Both packages are here; the choice is yours. None of the files is named final2annals, final3annals or final4annals, since the paper does not prove the Hodge conjecture unconditionally.

## Contents

| Folder or file | What it is |
|---|---|
| `submission-math-annalen/` | **Recommended: Mathematische Annalen.** The manuscript PDF and LaTeX source (`-final4`), a cover letter, and a checklist with Springer's declarations. |
| `submission-annals/` | The Annals of Mathematics, if you prefer to try it first. The same manuscript, a letter to the editors, and a checklist with the journal's AI policy. Submit at https://ef.msp.org/submit/annals. |
| `final4/` | The three paper files with the v1.8.0 DOI on the title page: PDF, tex.zip (figures as PNG) and arXiv tarball, named with `-final4`. |
| `priority-check-2026-10-15.md` | The dated check of arXiv, Zenodo and the web made before release v1.8.0, for the Batyrev proof and the degrees divisible by 33 or 39. |
| `priority-check-2026-10-11*.md` | The checks made before releases v1.6.0 and v1.7.0, for the degrees divisible by 57, 44, 52 and 51. |
| `release-v1.8.0/` | The three files attached to the GitHub release, byte for byte. They predate the DOI note on the title page. |
| `source/` | The repository at `main`, with the paper source, the figures, all checks and CI. The folder `sources/`, the author's own reference material, is left out. |
| `records/` | The GitHub release record and the Zenodo record of v1.8.0. |

## Before submitting

Confirm two lines that only you can confirm. The first is "The author received no funding for this work". The second is "The author has no competing interests to declare". Then read Section 8, "A note on preparation". It lists the ideas an AI assistant proposed and where they appear. Adjust it if your own account of the work differs.

## Checks

On `main`, CI runs `verification/shell/run_all.sh` and the Mathlib build, and both pass:

- Python, Julia and C agree on every finite step, including the seven block patterns and the parity at the levels 33 and 39.
- Both Lean projects build with the standard axioms only, with no `sorry` and no `native_decide`. The Mathlib project has 45 main theorems, among them the block patterns and the parity.
- The interval certificates of the second proof pass at 1000 and at 600 bits, and contour integrals match the residues to 15 digits.
- The Macaulay2 scripts pass.
- All 92 references were checked against an online record (`source/verification/references/report.md`).
