# Priority check for Theorem A, 11 October 2026 (about 05:05 UTC)

Release v1.7.0 adds to Theorem A of "On the Hodge conjecture for Fermat varieties" the degrees
m = 2^a 3^b 17^c with a ≤ 1, in every dimension, for their products and for the abelian varieties of
Fermat type of these degrees. When 51 does not divide m these degrees are 2^a 3^b, 17^c or 2·17^c and
the theorem is Aoki's; the new degrees are those divisible by 51: 51, 102, 153, 306, 459, …. The
degrees 2^a 11^b, 2^a 13^b and 2^a 3^b 19^c were checked before releases v1.5.0, v1.6.0 and v1.4.0
(the check of 00:32 UTC today is kept beside this one). Before release v1.7.0 we checked again.

| Source | Query | Finding |
|---|---|---|
| arXiv (API, newest first) | `all:Fermat AND all:Hodge`; `abs:Fermat AND abs:Hodge` | Nothing new since the last check. The newest relevant paper is still Miranda, Movasati, Rufino and Villaflor, arXiv 2609.27301v2 (23 Sept 2026): the Hodge conjecture for the Fermat varieties of degree d < 65 with d ≠ 44, 51, 52, in every dimension. So degree 51 is excluded there, and 102, 153, … lie outside its range. Next are 2609.12759 (Chern characters on hypersurfaces) and Jumagulov, 2608.18134 (odd fourfolds up to degree 199, which covers the fourfold of degree 51 and no other dimension). |
| Zenodo (API) | "Fermat AND Hodge", "Fermat AND 51 AND Hodge", "Fermat AND 102 AND Hodge" | Our own release v1.6.0 (10.5281/zenodo.23289930); Peterson's degree 35 (10.5281/zenodo.22945544); Saller's sums of binary quartics (10.5281/zenodo.23287572, degree 4); a note on the 5-adic intermediate Jacobian of the quintic Fermat threefold (10.5281/zenodo.22877751); our author's Weil-class paper (10.5281/zenodo.23227940), which does not treat Fermat varieties of degree 51; unrelated claims. Nothing for 102. |
| github.com/openai/math, CONTENTS.md (9142 lines) | "Fermat", "Hodge" | No Fermat-variety result. Result 032 still claims the rational Hodge conjecture for every CM abelian variety; it would imply the conjecture for every Fermat variety (Theorem E of the paper), but it is unrefereed and Theorem A does not use it. |
| Palomar registry (data.palomar-registry.org/api/v1/results, revision 217) | `q=Fermat`, `q=Hodge` | No entry on Hodge classes of Fermat varieties: the Fermat entry is the generalized Fermat equation x² + y⁵ = z⁷; the Hodge entries are Markman's Weil classes on abelian sixfolds and two unrelated results. |
| OpenRefute (the-omega-institute/trureturing at 04f6dbe, 11 Oct 2026) | file names containing "Hodge" or "Fermat" | No problem on Hodge classes or Fermat varieties: Fermat primes, Fermat's little theorem, a combinatorial Hodge theory reference and Anthropic's Lean proof of Fermat's Last Theorem. |
| The web | "Hodge conjecture Fermat variety degree 51 OR 102" | Only arXiv 2609.27301, which excludes 51. |

Conclusion:

- For the degrees 2^a 3^b 17^c with a ≤ 1 divisible by 51 (51, 102, 153, 306, 459, …), Theorem A is
  the first proof in every dimension. The only other source that would cover them is the unrefereed
  CM claim in github.com/openai/math. For the fourfold of degree 51 alone, Jumagulov's theorem and
  Theorem B of the paper also apply.
- Below degree 65, the preprint of MMRV leaves out only 44, 51 and 52, and Theorem A now covers all
  three. Their degree 55, like their 57, ends with Kang's statement about Fermat fourfolds (their
  Proposition 4.3), whose proof has a gap (Remark 3.21 of the paper), so 55 is not settled
  independently of it, and neither are 110 and 220.
- The Hodge conjecture itself is not proved, for Fermat varieties or in general.
