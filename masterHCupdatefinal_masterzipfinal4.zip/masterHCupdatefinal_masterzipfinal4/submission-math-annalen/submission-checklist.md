# Submission to Mathematische Annalen: checklist

Submit on the journal's page at Springer (link.springer.com/journal/208, "Submit manuscript"). No arXiv endorsement is needed. The Zenodo record serves as the public preprint.

## Files to upload

| File | Use |
|---|---|
| `on-the-hodge-conjecture-for-fermat-varieties-final4.pdf` | The manuscript, 83 pages. |
| `on-the-hodge-conjecture-for-fermat-varieties-tex-final4.zip` | The LaTeX source (`main.tex`, `sections/`, `references.bib`) with the five figures as PNG. Springer asks for the source as well as the PDF. |
| `cover-letter.txt` | Paste it into the cover-letter field, or upload it. |

## Metadata to enter

- **Title:** On the Hodge conjecture for Fermat varieties
- **Author:** Deep Bhattacharjee (sole author)
- **Affiliation:** Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha 751030, India
- **Emails:** d.bhattacharjee@erl-forschung.de, itsdeep@live.com
- **ORCID:** 0000-0003-0466-750X
- **MSC 2020:** 14C30 (primary); 14C25, 14J70, 14K22, 14M25, 14E30, 65G40 (secondary)
- **Keywords:** Hodge conjecture; Fermat varieties; uniruled varieties; Fine interior; Abel–Jacobi map; coniveau; CM abelian varieties; Weil classes; motivated cycles
- **Abstract:** We prove the Hodge conjecture for the Fermat varieties of degrees 44, 51, 52 and 114 in every dimension, and more generally of every degree 2^a 3^b 11^c, every degree 2^a 3^b 13^c and every degree 2^a 3^b 19^c or 2^a 3^b 17^c with a ≤ 1, together with their products and the abelian varieties of Fermat type of these degrees. The key step is that the quotient of a Fermat threefold by the kernel of a suitable character is uniruled, by Batyrev's criterion for toric hypersurfaces; a second proof uses families of curves and a residue formula for their Abel–Jacobi maps. We also prove the Hodge conjecture for Fermat fourfolds of every odd degree, and determine which combinations of the standard conjectures around the Hodge conjecture imply it.

## Declarations

Springer journals return a submission as incomplete when these are missing. The submission form asks for them. Only the author can confirm the first two, so check them before submitting.

- **Funding:** "The author received no funding for this work." Confirm this, or name the funder.
- **Competing interests:** "The author has no competing interests to declare." Confirm this.
- **Data and code availability:** "The LaTeX source, the figures and the verification code are available at https://github.com/creelie/e84hc and archived on Zenodo under the DOI 10.5281/zenodo.23234362 (this version: 10.5281/zenodo.23401546)."
- **Use of AI tools:** "Parts of the text and code were drafted with the help of an AI assistant working under the author's direction. The author takes full responsibility for the content." Section 8 of the paper lists the ideas the assistant proposed and where they appear.
- **Author contributions:** sole author.

## Before you press submit

- The PDF and the tex.zip were built from the same source, release v1.8.0 with its version DOI on the title page. Every check passes in CI: Python, Julia and C agree on every finite step, including the block patterns of Corollary 4.28; both Lean projects build with standard axioms only, including the files for degrees 114, 44, 52 and 51 and the block patterns; the six interval certificates of the second proof pass at 1000 and 600 bits; and the Macaulay2 scripts pass.
- The proof of Theorem A uses no computer. The interval certificates belong to the second proof of the coniveau step, which the paper keeps as a cross-check.
- The manuscript is not under consideration anywhere else. The cover letter says so.
- The system may ask for suggested reviewers. Choose researchers who work on algebraic cycles on Fermat varieties, toric hypersurfaces or abelian varieties, and avoid anyone you have collaborated with.
